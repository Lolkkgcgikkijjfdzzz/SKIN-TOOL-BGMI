#!/usr/bin/env python3
import os, sys, struct, shutil, random, time, re, bisect
from pathlib import Path
from datetime import datetime
from typing import List, Tuple, Dict, Set, Optional

class Config:
    BASE = Path(os.getcwd())
    MINI_SRC = BASE / "orignal" / "mini"
    ZSDIC_SRC = BASE / "orignal" / "zsdic"
    DUMP = BASE / "orignal" / "dump_full.txt"
    MODGUN = BASE / "modgun.txt"
    MODCLOTH = BASE / "modcloth.txt"
    LOBBY_TXT = BASE / "LOBBY.txt"
    LOBBY1_TXT = BASE / "lobby1.txt"
    NULL_TXT = BASE / "null.txt"
    MINI_OUT = BASE / "MINI"
    ZSDIC_OUT = BASE / "ZSDIC"
    STOCKS_TXT = BASE / "attachments and stocks.txt"

class CLR:
    # Basic Colors
    R='\033[38;5;196m'; G='\033[38;5;46m'; Y='\033[38;5;226m'; B='\033[38;5;27m'
    C='\033[38;5;51m'; M='\033[38;5;201m'; W='\033[38;5;231m'; O='\033[38;5;208m'
    
    # Premium Gradients & Shades
    N1='\033[38;5;213m'; N2='\033[38;5;177m'; N3='\033[38;5;141m' # Neon Pink/Purple
    T1='\033[38;5;121m'; T2='\033[38;5;85m'; T3='\033[38;5;49m'   # Teal/Cyan
    G1='\033[38;5;240m'; G2='\033[38;5;244m'; G3='\033[38;5;250m' # Grays
    
    # Special Styles
    BOLD='\033[1m'; DIM='\033[2m'; ITL='\033[3m'; UND='\033[4m'; RST='\033[0m'
    BG_D='\033[48;5;232m'; BG_L='\033[48;5;235m'

def clear(): os.system('cls' if os.name=='nt' else 'clear')

def is_item_asset(filename: str) -> bool:
    name = filename.lower()
    return name.startswith('item.') and (name.endswith('.uasset') or name.endswith('.uexp'))

def header(title, sub=""):
    clear()
    # High-End ASCII Art with Neon Glow
    print(f"\n{CLR.N1}  ██████  ███████ ███    ███ ██   ██      {CLR.T1}████████  ██████   ██████  ██      ")
    print(f"{CLR.N2}  ██       ██      ████  ████  ██ ██          {CLR.T2}██    ██    ██ ██    ██ ██      ")
    print(f"{CLR.N3}  █████   █████   ██ ████ ██   ███           {CLR.T3}██    ██    ██ ██    ██ ██      ")
    print(f"{CLR.N2}      ██  ██      ██  ██  ██  ██ ██          {CLR.T2}██    ██    ██ ██    ██ ██      ")
    print(f"{CLR.N1}  ██████   ███████ ██      ██ ██   ██         {CLR.T1}██     ██████   ██████  ███████ ")
    
    print(f"\n{CLR.G1}  {'━'*64}")
    print(f"  {CLR.BOLD}{CLR.W}{title.upper():^64}{CLR.RST}")
    if sub:
        print(f"  {CLR.DIM}{CLR.T2}{sub:^64}{CLR.RST}")
    print(f"{CLR.G1}  {'━'*64}{CLR.RST}\n")

def msg(t, m):
    c = {
        '+': (f"{CLR.G}✔", CLR.W),
        '!': (f"{CLR.Y}⚠", CLR.Y),
        'x': (f"{CLR.R}✘", CLR.R),
        '*': (f"{CLR.C}✦", CLR.T2),
        '#': (f"{CLR.M}⚙", CLR.N2)
    }
    icon, text_color = c.get(t, (f"{CLR.W}•", CLR.W))
    print(f"  {icon}{CLR.RST} {text_color}{m}{CLR.RST}")

_dump_cache = None
def load_dump() -> Dict[str, dict]:
    global _dump_cache
    if _dump_cache is not None: return _dump_cache
    info = {}
    if not Config.DUMP.exists():
        msg('x', f"Dump not found: {Config.DUMP}")
        _dump_cache = info
        return info
    for line in Config.DUMP.read_text(errors='ignore').splitlines():
        if '|' not in line: continue
        parts = [p.strip() for p in line.split('|')]
        if len(parts) >= 3 and parts[0].replace(' ','').isdigit():
            info[parts[0].strip()] = {'hex': parts[1].replace(' ','').lower(), 'name': parts[2]}
    _dump_cache = info
    return info

def get_hex(id_str: str) -> str:
    d = load_dump()
    if id_str in d and d[id_str]['hex']: return d[id_str]['hex']
    try: return struct.pack('<I', int(id_str)).hex()
    except: return ""

def get_name(id_str: str) -> str:
    d = load_dump()
    return d.get(id_str, {}).get('name', f'ID_{id_str}')

def load_pairs(txt_path: Path) -> List[Tuple[str, str]]:
    pairs = []
    if not txt_path.exists():
        msg('x', f"File not found: {txt_path.name}")
        return pairs
    for line in txt_path.read_text(errors='ignore').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or ',' not in line: continue
        p = line.split(',', 1)
        a, b = p[0].strip(), p[1].strip()
        if a and b: pairs.append((a, b))
    return pairs

def find_hex(data: bytes, hex_str: str) -> List[int]:
    offsets = []
    try:
        needle = bytes.fromhex(hex_str)
        s = 0
        while True:
            idx = data.find(needle, s)
            if idx == -1: break
            offsets.append(idx)
            s = idx + 1
    except: pass
    return offsets

_all_skins_cache = None
def load_all_skins_data() -> Dict[str, dict]:
    global _all_skins_cache
    if _all_skins_cache is not None: return _all_skins_cache
    _all_skins_cache = {}
    paths = [
        Config.BASE / "ALL.txt",
        Config.BASE / "orignal" / "mini" / "TXTS" / "ALL.txt",
        Config.BASE / "orignal" / "ALL.txt",
    ]
    valid = next((p for p in paths if p.exists()), None)
    if not valid:
        msg('!', "ALL.txt not found — size fix will be skipped")
        return _all_skins_cache
    for line in valid.read_text(encoding='utf-8', errors='ignore').splitlines():
        parts = line.strip().split('|')
        if len(parts) >= 2:
            sid  = parts[0].strip()
            hx   = parts[1].strip().lower()
            name = parts[2].strip() if len(parts) >= 3 else ""
            _all_skins_cache[sid] = {'hex': hx, 'name': name}
    return _all_skins_cache

CHUNK_SIZE_MS = 65536

def mini_skins_mod_skin(orig_files, orig_base, pairs, skins_data, index_data, edited_dir):
    ms_changelog = []
    modified_blocks_map = {}

    resolved_ops = []
    missing_ids = set()
    for have_id, want_id in pairs:
        if have_id not in skins_data: missing_ids.add(have_id); continue
        if want_id not in skins_data: missing_ids.add(want_id); continue
        resolved_ops.append({
            'search_hex':   skins_data[want_id]['hex'],
            'replace_hex':  skins_data[have_id]['hex'],
            'search_name':  skins_data[want_id]['name'],
            'replace_name': skins_data[have_id]['name'],
            'label':        f"{have_id} -> {want_id}",
        })

    if missing_ids:
        msg('!', f"{len(missing_ids)} ID(s) not in ALL.txt: {', '.join(sorted(missing_ids))}")
    if not resolved_ops:
        msg('x', "No valid ops — check modcloth.txt IDs exist in ALL.txt")
        return ms_changelog, modified_blocks_map

    if edited_dir.exists():
        import shutil as _sh; _sh.rmtree(edited_dir)
    edited_dir.mkdir(parents=True, exist_ok=True)

    for fpath in orig_files:
        rel = fpath.relative_to(orig_base).as_posix()
        try: content_bytes = fpath.read_bytes()
        except Exception as e: msg('x', f"Cannot read {rel}: {e}"); continue

        hex_data = content_bytes.hex()
        file_modified = False
        dst_key = str(edited_dir / rel)

        for op in resolved_ops:
            s_hex = op['search_hex']; r_hex = op['replace_hex']
            s_name = op['search_name']; r_name = op['replace_name']
            if s_hex not in hex_data: continue

            all_pos = []
            start = 0; hlen = len(s_hex)
            while True:
                p = hex_data.find(s_hex, start)
                if p == -1: break
                all_pos.append(p); start = p + hlen

            if len(all_pos) < 2: continue

            best_i, best_gap = 0, all_pos[1] - all_pos[0]
            for i in range(1, len(all_pos) - 1):
                g = all_pos[i+1] - all_pos[i]
                if g < best_gap: best_gap = g; best_i = i

            first_pos  = all_pos[best_i]
            second_pos = all_pos[best_i + 1]
            hex_data = hex_data[:second_pos] + r_hex + hex_data[second_pos + hlen:]
            file_modified = True

            _blk = (second_pos // 2) // CHUNK_SIZE_MS
            if dst_key not in modified_blocks_map: modified_blocks_map[dst_key] = set()
            modified_blocks_map[dst_key].update({max(0, _blk-1), _blk, _blk+1})

            src_idx = tgt_idx = "N/A"; idx_occ = 0; idx_reason = ""
            if s_name in index_data and r_name in index_data:
                repl_idx = index_data[r_name][0]
                w_start = max(0, first_pos - 60)
                window = hex_data[w_start:first_pos]
                for cand in index_data[s_name]:
                    if cand in window:
                        src_idx = cand; tgt_idx = repl_idx
                        real_idx = w_start + window.find(cand)
                        hex_data = (hex_data[:w_start] +
                                    window.replace(cand, repl_idx, 1) +
                                    hex_data[first_pos:])
                        idx_occ = 1
                        _ib = (real_idx // 2) // CHUNK_SIZE_MS
                        modified_blocks_map[dst_key].update({max(0, _ib-1), _ib, _ib+1})
                        break
                else: idx_reason = "Index hex not found in window"
            else: idx_reason = "Index names missing"

            ms_changelog.append({
                'id_pair': f"{op['label']} (REPLACE)", 'file_name': rel,
                'source_item': f"{s_name} [Found]", 'target_item': f"{r_name} [Applied]",
                'source_hex': s_hex, 'target_hex': r_hex,
                'source_index': src_idx, 'target_index': tgt_idx,
                'index_occurrences': idx_occ, 'index_failure_reason': idx_reason,
            })
            msg('+', f"{rel}  —  {op['label']}")

        if file_modified:
            dst = edited_dir / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            try: dst.write_bytes(bytes.fromhex(hex_data))
            except Exception as e: msg('x', f"Write failed {rel}: {e}")

    return ms_changelog, modified_blocks_map

def mini_lobby_mod_skin(orig_files, orig_base, pairs, edited_dir):
    ms_changelog = []
    modified_blocks_map = {}
    
    skins_data = load_all_skins_data()

    if edited_dir.exists():
        import shutil as _sh; _sh.rmtree(edited_dir)
    edited_dir.mkdir(parents=True, exist_ok=True)

    for fpath in orig_files:
        rel = fpath.relative_to(orig_base).as_posix()
        try: content_bytes = fpath.read_bytes()
        except: continue

        hex_data = content_bytes.hex()
        file_modified = False
        dst_key = str(edited_dir / rel)

        for id1, id2 in pairs:
            # Get hexes from ALL.txt or fallback
            h1 = skins_data.get(id1, {}).get('hex', get_hex(id1)).lower()
            h2 = skins_data.get(id2, {}).get('hex', get_hex(id2)).lower()
            
            if not h1 or not h2: continue
            if h1 not in hex_data or h2 not in hex_data: continue

            # Find all positions of h1 and h2
            pos_h1 = []
            start = 0; hlen1 = len(h1)
            while True:
                p = hex_data.find(h1, start)
                if p == -1: break
                pos_h1.append(p); start = p + hlen1
                
            pos_h2 = []
            start = 0; hlen2 = len(h2)
            while True:
                p = hex_data.find(h2, start)
                if p == -1: break
                pos_h2.append(p); start = p + hlen2

            if not pos_h1 or not pos_h2: continue

            # Use 2nd occurrence (data entry), fall back to 1st if only one exists
            p1 = pos_h1[1] if len(pos_h1) >= 2 else pos_h1[0]
            p2 = pos_h2[1] if len(pos_h2) >= 2 else pos_h2[0]

            # Extract index: 2 bytes immediately before the hex (at offset -16 in hex string = -8 bytes)
            idx1 = hex_data[p1-16:p1-14] if p1 >= 16 else ""
            idx2 = hex_data[p2-16:p2-14] if p2 >= 16 else ""

            if not idx1 or not idx2: continue

            # ONE-WAY replacement: put id1 (Default/HAVE) hex+index into id2 (Target/WANT) slot
            new_hex = list(hex_data)
            new_hex[p2-16:p2-14] = list(idx1)   # replace id2's index with id1's index
            new_hex[p2:p2+hlen2] = list(h1)      # replace id2's hex with id1's hex

            hex_data = "".join(new_hex)
            file_modified = True

            _blk = (p2//2) // CHUNK_SIZE_MS
            if dst_key not in modified_blocks_map: modified_blocks_map[dst_key] = set()
            modified_blocks_map[dst_key].update({max(0,_blk-1), _blk, _blk+1})

            ms_changelog.append({
                'id_pair': f"{id1} -> {id2} (LOBBY)", 'file_name': rel,
                'source_hex': h2, 'target_hex': h1,
                'source_index': idx2, 'target_index': idx1
            })
            msg('+', f"{rel}  —  {id1} -> {id2}")

        if file_modified:
            dst = edited_dir / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(bytes.fromhex(hex_data))

    return ms_changelog, modified_blocks_map


def run_mini_lobby():
    header("MINI > LOBBY", "Precision Lobby Swapper")
    orig_base    = Config.BASE / "orignal" / "mini"
    out_base     = Config.BASE / "MINI" / "LOBBY"
    edited_dir   = out_base / "EDITED"
    size_fix_dir = out_base / "SIZE_FIXED"
    text_dir     = out_base / "TEXT"

    orig_files = list(orig_base.rglob("HallThemeItem.uexp"))
    if not orig_files:
        msg('x', f"HallThemeItem.uexp not found in {orig_base}"); input("\n  Press Enter..."); return
    msg('+', f"Found {len(orig_files)} HallThemeItem.uexp file(s)")

    pairs = load_pairs(Config.LOBBY_TXT)
    if not pairs:
        msg('x', "No pairs in LOBBY.txt"); input("\n  Press Enter..."); return
    msg('+', f"Loaded {len(pairs)} pairs from LOBBY.txt")

    t0 = time.time(); print()

    msg('*', "=== STEP 2: MOD LOBBY ===")
    changelog, blocks_map = mini_lobby_mod_skin(orig_files, orig_base, pairs, edited_dir)
    msg('+', f"Mod Lobby done — {len(set(e['file_name'] for e in changelog))} file(s) modified")
    if not changelog:
        msg('!', "No replacements made — check IDs and ensure hexes appear in file")
        input("\n  Press Enter..."); return
    print()

    msg('*', "=== STEP 3: EXCLUDE + CHANGELOG ===")
    exclude_hexes = ms_generate_exclude(text_dir, changelog)
    msg('+', f"exclude.txt: {len(exclude_hexes)} protected hexes")
    try:
        lines = ["MINI LOBBY Changelog\n" + "="*30 + "\n"]
        for i, e in enumerate(changelog, 1):
            lines.append(f"{'='*30}\n{i}. ID PAIR: {e['id_pair']}\nFILE: {e['file_name']}\n"
                         f"HEX:   {e['source_hex']} -> {e['target_hex']}\n"
                         f"INDEX: {e['source_index']} -> {e['target_index']}\n")
        (text_dir / 'changelog.txt').write_text('\n'.join(lines), encoding='utf-8')
        msg('+', f"changelog.txt: {len(changelog)} entries")
    except Exception as ex: msg('!', f"changelog write failed: {ex}")
    print()

    msg('*', "=== STEP 4: SIZE FIX ===")
    skins_data = load_all_skins_data()
    if skins_data:
        fn, tocc, nlog = mini_skins_size_fix(
            edited_dir, size_fix_dir, skins_data, exclude_hexes, blocks_map)
        print()
        msg('+', f"Size Fix done — {fn} file(s), {tocc} occurrences nulled")
    else:
        msg('!', "ALL.txt missing — size fix skipped")

    print(f"\n  {CLR.G}{CLR.BOLD}══════════════════════════════════════{CLR.RST}")
    msg('+', f"MINI LOBBY complete in {time.time()-t0:.1f}s")
    msg('*', f"Edited     : {edited_dir}")
    msg('*', f"Size Fixed : {size_fix_dir}")
    msg('*', f"Logs       : {text_dir}")
    print(f"  {CLR.G}{CLR.BOLD}══════════════════════════════════════{CLR.RST}")
    input("\n  Press Enter...")

def _ms_build_pattern_groups(hex_list):
    groups = {}
    for hx in hex_list:
        try: b = bytes.fromhex(hx)
        except ValueError: continue
        if b: groups.setdefault(len(b), set()).add(b)
    return groups

def _ms_null_in_blocks(file_path, pattern_groups, dirty_blocks, target_counts=None):
    if target_counts is None: target_counts = {2}
    if not dirty_blocks: return 0
    try: data = bytearray(file_path.read_bytes())
    except: return 0
    total_hits = 0; modified = False; fsz = len(data)
    for blk in dirty_blocks:
        s = blk * CHUNK_SIZE_MS
        if s >= fsz: continue
        e = min(s + CHUNK_SIZE_MS, fsz); blen = e - s
        mv = memoryview(data)[s:e]
        for L, patterns in pattern_groups.items():
            if L <= 0 or blen < L: continue
            zero = b'\x00' * L; occ = {}
            i = 0
            while i <= blen - L:
                chunk = bytes(mv[i:i+L])
                if chunk in patterns: occ.setdefault(chunk, []).append(i); i += L
                else: i += 1
            for pat, pos_list in occ.items():
                if len(pos_list) not in target_counts: continue
                for p in pos_list: data[s+p:s+p+L] = zero
                total_hits += len(pos_list); modified = True
    if modified: file_path.write_bytes(data)
    return total_hits

def mini_skins_size_fix(edited_dir, size_fixed_dir, skins_data, exclude_hexes, modified_blocks_map):
    import shutil as _sh2
    excl_kw = {'face', 'hair', 'head', 'male', 'female'}
    valid_hexes = []
    sk = sz = 0
    for sid, info in skins_data.items():
        hx = info['hex']; nm = info['name'].lower()
        if any(k in nm for k in excl_kw): sk += 1; continue
        if '0000' in hx: sz += 1; continue
        if hx in exclude_hexes: continue
        valid_hexes.append(hx)
    msg('*', f"ALL.txt: {len(skins_data)} total | skip_name={sk} skip_zeros={sz} excluded={len(exclude_hexes)} | pool={len(valid_hexes)}")
    if not valid_hexes: msg('!', "No hex candidates — size fix skipped"); return 0, 0, []
    edit_files = list(edited_dir.rglob("*.uexp"))
    if not edit_files: msg('!', "No .uexp in EDITED — size fix skipped"); return 0, 0, []
    if size_fixed_dir.exists(): _sh2.rmtree(size_fixed_dir)
    size_fixed_dir.mkdir(parents=True, exist_ok=True)
    pg = _ms_build_pattern_groups(valid_hexes)
    files_nulled = total_occ = 0; nulled_log = []
    for idx, fpath in enumerate(edit_files, 1):
        rel = fpath.relative_to(edited_dir).as_posix()
        dst = size_fixed_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        try: _sh2.copy2(fpath, dst)
        except Exception as e: msg('x', f"Copy failed {rel}: {e}"); continue
        dirty = modified_blocks_map.get(str(fpath), set())
        hits  = _ms_null_in_blocks(dst, pg, dirty, {2})
        pct = idx / len(edit_files); filled = int(30 * pct)
        bar = '█' * filled + '░' * (30 - filled)
        print(f"\r  {CLR.C}[{CLR.G}{bar}{CLR.C}] {CLR.Y}{pct*100:5.1f}%{CLR.RST}  "
              f"File {CLR.W}{idx}/{len(edit_files)}{CLR.RST}  Occ {CLR.G}{total_occ+hits}{CLR.RST}{' '*8}",
              end='', flush=True)
        if hits > 0: files_nulled += 1; total_occ += hits; nulled_log.append((rel, hits))
    print()
    return files_nulled, total_occ, nulled_log

def ms_generate_exclude(text_dir, changelog_entries):
    exclude = set()
    for e in changelog_entries:
        exclude.add(e['source_hex'].lower()); exclude.add(e['target_hex'].lower())
        if e.get('source_index') and e['source_index'] != 'N/A': exclude.add(e['source_index'].lower())
        if e.get('target_index') and e['target_index'] != 'N/A': exclude.add(e['target_index'].lower())
    text_dir.mkdir(parents=True, exist_ok=True)
    (text_dir / 'exclude.txt').write_text(
        '# Hex excluded from nulling (auto-generated)\n' + ' '.join(sorted(exclude)),
        encoding='utf-8')
    return exclude

def run_mini_skins():
    header("MINI > SKINS", "Precision Skin Swapper")
    orig_base    = Config.BASE / "orignal" / "mini"
    out_base     = Config.BASE / "MINI" / "SKINS"
    edited_dir   = out_base / "EDITED"
    size_fix_dir = out_base / "SIZE_FIXED"
    text_dir     = out_base / "TEXT"

    orig_files = list(orig_base.rglob("*.uexp")) if orig_base.exists() else []
    if not orig_files:
        msg('x', f"No .uexp files in {orig_base}"); input("\n  Press Enter..."); return

    msg('+', f"Found {len(orig_files)} .uexp file(s)")
    pairs = load_pairs(Config.MODGUN)
    if not pairs:
        msg('x', "No pairs in modgun.txt"); input("\n  Press Enter..."); return
    msg('+', f"Loaded {len(pairs)} pairs from modgun.txt")

    skins_data = load_all_skins_data()
    if skins_data: msg('+', f"ALL.txt: {len(skins_data)} entries")
    else: msg('!', "ALL.txt not loaded — size fix skipped")

    index_data = load_index_data()
    if index_data: msg('+', f"index.txt: {len(index_data)} entries")
    else: msg('!', "index.txt not loaded — index swap skipped")

    t0 = time.time(); print()

    msg('*', "=== STEP 2: MOD SKIN ===")
    changelog, blocks_map = mini_skins_mod_skin(
        orig_files, orig_base, pairs, skins_data, index_data, edited_dir)
    msg('+', f"Mod Skin done — {len(set(e['file_name'] for e in changelog))} file(s) modified")
    if not changelog:
        msg('!', "No replacements made — check IDs in ALL.txt and hex appears ≥2 times")
        input("\n  Press Enter..."); return
    print()

    msg('*', "=== STEP 3: EXCLUDE + CHANGELOG ===")
    exclude_hexes = ms_generate_exclude(text_dir, changelog)
    for _p in [Config.MODGUN]:
        for _h, _w in load_pairs(Path(_p)):
            for _sid in (_h, _w):
                if _sid in skins_data: exclude_hexes.add(skins_data[_sid]['hex'].lower())
    msg('+', f"exclude.txt: {len(exclude_hexes)} protected hexes")
    text_dir.mkdir(parents=True, exist_ok=True)
    try:
        lines = ["🌟 SEMX Tool — MINI SKINS Changelog 🌟\n" + "="*30 + "\n"]
        for i, e in enumerate(changelog, 1):
            lines.append(f"{'='*30}\n{i}. ID PAIR: {e['id_pair']}\nFILE: {e['file_name']}\n"
                         f"Source: {e['source_item']}\nTarget: {e['target_item']}\n"
                         f"HEX: {e['source_hex']} → {e['target_hex']}\n")
            if e.get('index_occurrences', 0) > 0:
                lines.append(f"INDEX: {e['source_index']} → {e['target_index']}\n")
            elif e.get('index_failure_reason'):
                lines.append(f"Index note: {e['index_failure_reason']}\n")
            lines.append("="*30 + "\n")
        (text_dir / 'changelog.txt').write_text('\n'.join(lines), encoding='utf-8')
        msg('+', f"changelog.txt: {len(changelog)} entries")
    except Exception as ex: msg('!', f"changelog write failed: {ex}")
    print()

    msg('*', "=== STEP 4: SIZE FIX ===")
    if skins_data:
        fn, tocc, nlog = mini_skins_size_fix(
            edited_dir, size_fix_dir, skins_data, exclude_hexes, blocks_map)
        print()
        msg('+', f"Size Fix done — {fn} file(s), {tocc} occurrences nulled")
        try:
            nlines = [f"Nulled Report\n=============\nMode: occ=2 block-based\n"
                      f"Files modified: {fn}\nTotal occ nulled: {tocc}\nExcluded: {len(exclude_hexes)}\n"]
            for r, h in nlog: nlines.append(f"[FILE] {r}  — {h} occ nulled")
            (text_dir / 'nulled.txt').write_text('\n'.join(nlines), encoding='utf-8')
        except Exception as ex: msg('!', f"nulled.txt write failed: {ex}")
    else:
        msg('!', "ALL.txt missing — size fix skipped")

    print(f"\n  {CLR.G}{CLR.BOLD}══════════════════════════════════════{CLR.RST}")
    msg('+', f"MINI SKINS complete in {time.time()-t0:.1f}s")
    msg('*', f"Edited     : {edited_dir}")
    msg('*', f"Size Fixed : {size_fix_dir}")
    msg('*', f"Logs       : {text_dir}")
    print(f"  {CLR.G}{CLR.BOLD}══════════════════════════════════════{CLR.RST}")
    input("\n  Press Enter...")
    print()


_index_cache = None
def load_index_data() -> Dict[str, List[str]]:
    global _index_cache
    if _index_cache is not None: return _index_cache
    
    paths = [
        Config.BASE / "index.txt",
        Config.BASE / "orignal" / "index.txt",
        Config.BASE / "orignal" / "mini" / "TXTS" / "index.txt",
        Path(r"D:\12.BGMI-3.5\42Official\PAID Group\Skin\Skins\SIMPLE MINI OBB TOOL\MINI_ICON\TXTS\index.txt")
    ]
    _index_cache = {}
    valid_path = None
    for p in paths:
        if p.exists():
            valid_path = p
            break
            
    if not valid_path:
        msg('x', "index.txt not found! Item.uexp index swapping will be skipped.")
        return _index_cache
        
    for line in valid_path.read_text(encoding='utf-8', errors='ignore').splitlines():
        parts = line.strip().split('|')
        if len(parts) >= 4:
            name = parts[2].strip()
            index_hex = parts[3].strip().lower()
            _index_cache.setdefault(name, []).append(index_hex)
    return _index_cache

def pad_hex_zeros(src_bytes: bytes, target_len: int) -> bytes:
    if len(src_bytes) >= target_len: return src_bytes[:target_len]
    to_add = target_len - len(src_bytes)
    res = bytearray(src_bytes)
    idx = res.find(0x00)
    if idx < 0:
        res.extend(b'\x00' * to_add)
    else:
        for _ in range(to_add): res.insert(idx + 1, 0x00)
    return bytes(res)

def mini_swap(data: bytearray, pairs: List[Tuple[str,str]], is_item: bool) -> List[Tuple[str,str,str,str]]:
    modified = []
    for have_id, want_id in pairs:
        h_have = get_hex(have_id)
        h_want = get_hex(want_id)
        if not h_have or not h_want: continue
        
        b_have = bytes.fromhex(h_have)
        b_want = bytes.fromhex(h_want)

        if is_item:
            locs_want = find_hex(data, h_want)
            locs_have = find_hex(data, h_have)
            
            if len(locs_want) < 2 or not locs_have: continue
            
            p_want_first = locs_want[0]
            p_have_target = locs_have[1] if len(locs_have) >= 2 else locs_have[0]
            
            def extract_index(content, baseline):
                search_end = baseline - 14
                non_zero_pos = -1
                for i in range(search_end - 1, -1, -1):
                    if content[i] != 0x00:
                        non_zero_pos = i
                        break
                if non_zero_pos >= 1:
                    if content[non_zero_pos - 1] == 0x00 and (non_zero_pos + 1) < len(content):
                        return non_zero_pos, bytes(content[non_zero_pos:non_zero_pos + 2])
                    else:
                        return non_zero_pos - 1, bytes(content[non_zero_pos - 1:non_zero_pos + 1])
                return -1, None

            want_idx_pos, want_idx_bytes = extract_index(data, p_want_first)
            have_idx_pos, have_idx_bytes = extract_index(data, p_have_target)
            
            hex_data = data.hex()
            occ = hex_data.count(h_want)
            if occ >= 2:
                first_pos = hex_data.find(h_want)
                second_pos = hex_data.find(h_want, first_pos + len(h_want))
                
                if second_pos != -1:
                    padded_have_bytes = pad_hex_zeros(b_have, len(b_want))
                    h_have_padded = padded_have_bytes.hex()
                    
                    hex_data = hex_data[:second_pos] + h_have_padded + hex_data[second_pos+len(h_want):]
                    
                    data[:] = bytes.fromhex(hex_data)
                    
                    if have_idx_bytes and want_idx_pos != -1:
                        data[want_idx_pos : want_idx_pos + 2] = have_idx_bytes
                        
                    modified.append((have_id, want_id, get_name(have_id), get_name(want_id)))
            continue
            
        else:
            locs_want = find_hex(data, h_want)
            if not locs_want: continue
            
            replaced = False
            for p in locs_want:
                if p + len(b_want) <= len(data):
                    repl = pad_hex_zeros(b_have, len(b_want))
                    data[p : p + len(b_want)] = repl[:len(b_want)]
                    replaced = True
                    
            if replaced:
                modified.append((have_id, want_id, get_name(have_id), get_name(want_id)))

    return modified

def zsdic_swap(data: bytearray, active_pair_ops: Dict, swap_offsets: Set[int] = None) -> List[Tuple[str,str,str,str]]:
    modified = []
    temp_data = bytes(data)
    for pair, info in active_pair_ops.items():
        id1, id2 = pair
        was_mod = False
        for op in info["ops"]:
            rx = op["rx"]
            for m in rx.finditer(temp_data):
                start = m.start()
                data[start : start + len(op["from"])] = op["to"]
                if swap_offsets is not None: swap_offsets.add(start)
                was_mod = True
        if was_mod:
            modified.append((id1, id2, get_name(id1), get_name(id2)))
    return modified

def load_null_ids(txt_path=None) -> List[Tuple[str, str]]:
    nulls = []
    target = txt_path if txt_path else Config.NULL_TXT
    if not target.exists(): return nulls
    for line in target.read_text(errors='ignore').splitlines():
        line = line.strip()
        if not line or '|' not in line: continue
        parts = [p.strip() for p in line.split('|')]
        if len(parts) >= 2:
            nulls.append((parts[0].split()[0], parts[1].replace(' ','').lower()))
    return nulls

def null_mini(data: bytearray, count: int, protected_hex: Set[str], null_ids: List[Tuple[str, str]]) -> int:
    if not null_ids or count <= 0: return 0
    random.shuffle(null_ids)
    applied = 0
    for nid, hex_str in null_ids:
        if applied >= count: break
        if hex_str in protected_hex: continue
        try:
            needle = bytes.fromhex(hex_str)
            if not needle: continue
            s = 0
            while applied < count:
                idx = data.find(needle, s)
                if idx == -1: break
                data[idx : idx + len(needle)] = b'\x00' * len(needle)
                applied += 1
                s = idx + len(needle)
        except: pass
    return applied

def null_zsdic(data: bytearray, count: int, protected_ids: Set[str], null_ids: List[Tuple[str, str]]) -> int:
    if not null_ids or count <= 0: return 0
    null_id_set = {nid for nid, h in null_ids}
    candidates = []
    orig_bytes = bytes(data)
    start_search = min(2048, len(data) // 4) if len(data) > 1024 else 0
    ID_ASCII_RE = re.compile(rb"(?<![0-9])[0-9]{3,}(?![0-9])")
    for m in ID_ASCII_RE.finditer(orig_bytes, start_search):
        start, end = m.start(), m.end()
        id_str = orig_bytes[start:end].decode("ascii", errors="ignore")
        if id_str in null_id_set and id_str not in protected_ids:
            l_len = (end - start) + 5
            if start + l_len <= len(data): candidates.append((start, l_len))
    for nid, h_str in null_ids:
        if nid in protected_ids: continue
        try:
            needle = bytes.fromhex(h_str)
            if len(needle) < 4: continue
            pos = start_search
            while True:
                pos = orig_bytes.find(needle, pos)
                if pos == -1: break
                l_len = len(needle) + 5
                if pos + l_len <= len(data): candidates.append((pos, l_len))
                pos += len(needle)
        except: pass
    if not candidates: return 0
    random.shuffle(candidates)
    applied = 0
    for pos, length in candidates[:count]:
        data[pos : pos + length] = b'\x00' * length
        applied += 1
    return applied

def build_protected_hex(pairs: List[Tuple[str,str]]) -> Set[str]:
    p = set()
    for src, tgt in pairs:
        h = get_hex(src)
        if h: p.add(h)
        h = get_hex(tgt)
        if h: p.add(h)
    return p

def build_protected_ids(pairs: List[Tuple[str,str]]) -> Set[str]:
    p = set()
    for src, tgt in pairs:
        p.add(src); p.add(tgt)
    return p

def zsdic_get_pair_ops(pairs: List[Tuple[str,str]], item_data_list: List[bytes]) -> Dict:
    def build_safe_pat(id_str):
        return re.compile(rb"(?<![0-9])" + re.escape(id_str.encode('ascii')) + rb"(?![0-9])")
    
    pair_ops = {}
    for id1, id2 in pairs:
        a1, a2 = id1.encode('ascii'), id2.encode('ascii')
        p1, p2 = build_safe_pat(id1), build_safe_pat(id2)
        pos1 = pos2 = None
        d1 = d2 = b""
        
        for data in item_data_list:
            if pos1 is None and (m := p1.search(data)): pos1, d1 = m.start(), data
            if pos2 is None and (m := p2.search(data)): pos2, d2 = m.start(), data
            if pos1 is not None and pos2 is not None: break
            
        if pos1 is None or pos2 is None:
            ops = []
            if len(a1) == len(a2):
                ops.append({"from": a1, "to": a2, "rx": re.compile(rb"(?<![0-9])" + re.escape(a1) + rb"(?![0-9])")})
                ops.append({"from": a2, "to": a1, "rx": re.compile(rb"(?<![0-9])" + re.escape(a2) + rb"(?![0-9])")})
            else:
                src, dst = (a2, a1) if len(a1) < len(a2) else (a1, a2)
                ops.append({"from": src, "to": dst.ljust(len(src), b'\x00'), "rx": re.compile(rb"(?<![0-9])" + re.escape(src) + rb"(?![0-9])")})
            pair_ops[(id1, id2)] = {"ops": ops, "lh1": a1, "lh2": a2}
            continue
        
        lh1 = a1 + d1[pos1 + len(a1): pos1 + len(a1) + 5]
        lh2 = a2 + d2[pos2 + len(a2): pos2 + len(a2) + 5]
        
        diff = abs(len(id1) - len(id2))
        ops = []
        
        if diff <= 1:
            if len(lh1) == len(lh2):
                ops.append({"from": lh1, "to": lh2, "rx": re.compile(rb"(?<![0-9])" + re.escape(lh1) + rb"(?![0-9])")})
                ops.append({"from": lh2, "to": lh1, "rx": re.compile(rb"(?<![0-9])" + re.escape(lh2) + rb"(?![0-9])")})
            elif len(lh1) > len(lh2):
                pad_lh2 = bytearray(lh2)
                to_add = len(lh1) - len(lh2)
                idx = pad_lh2.find(0x00)
                if idx < 0: pad_lh2.extend(b"\x00" * to_add)
                else: [pad_lh2.insert(idx, 0x00) for _ in range(to_add)]
                
                ops.append({"from": lh1, "to": bytes(pad_lh2), "rx": re.compile(rb"(?<![0-9])" + re.escape(lh1) + rb"(?![0-9])")})
                
                trunc_lh1 = bytearray(lh1)
                for _ in range(to_add):
                    idx = trunc_lh1.find(0x00)
                    if idx >= 0: del trunc_lh1[idx]
                    else: trunc_lh1 = trunc_lh1[:len(lh2)]
                ops.append({"from": lh2, "to": bytes(trunc_lh1), "rx": re.compile(rb"(?<![0-9])" + re.escape(lh2) + rb"(?![0-9])")})
            else:
                pad_lh1 = bytearray(lh1)
                to_add = len(lh2) - len(lh1)
                idx = pad_lh1.find(0x00)
                if idx < 0: pad_lh1.extend(b"\x00" * to_add)
                else: [pad_lh1.insert(idx, 0x00) for _ in range(to_add)]
                
                ops.append({"from": lh2, "to": bytes(pad_lh1), "rx": re.compile(rb"(?<![0-9])" + re.escape(lh2) + rb"(?![0-9])")})
                
                trunc_lh2 = bytearray(lh2)
                for _ in range(to_add):
                    idx = trunc_lh2.find(0x00)
                    if idx >= 0: del trunc_lh2[idx]
                    else: trunc_lh2 = trunc_lh2[:len(lh1)]
                ops.append({"from": lh1, "to": bytes(trunc_lh2), "rx": re.compile(rb"(?<![0-9])" + re.escape(lh1) + rb"(?![0-9])")})
        else:
            src, dst = (lh2, lh1) if len(id1) < len(id2) else (lh1, lh2)
            res_to = bytearray(dst)
            if len(dst) < len(src):
                to_add = len(src) - len(dst)
                idx = res_to.find(0x00)
                if idx < 0: res_to.extend(b"\x00" * to_add)
                else: [res_to.insert(idx, 0x00) for _ in range(to_add)]
            else:
                for _ in range(len(dst) - len(src)):
                    idx = res_to.find(0x00)
                    if idx >= 0: del res_to[idx]
                    else: res_to = res_to[:len(src)]
            ops.append({"from": src, "to": bytes(res_to), "rx": re.compile(rb"(?<![0-9])" + re.escape(src) + rb"(?![0-9])")})
            
        pair_ops[(id1, id2)] = {"ops": ops, "lh1": lh1, "lh2": lh2}
    return pair_ops

def null_zsdic_nearest(data: bytearray, swap_offsets: List[int], null_id_set: set, id_to_hex: dict, mod_ids: set, max_nulls: int):
    ID_ASCII_RE = re.compile(rb"(?<![0-9])[0-9]{3,}(?![0-9])")
    if not swap_offsets: return data, 0
    swap_offsets = sorted(swap_offsets)
    candidates = []
    orig_bytes = bytes(data)
    start_search = min(2048, len(data) // 4) if len(data) > 1024 else 0
    for m in ID_ASCII_RE.finditer(orig_bytes, start_search):
        start, end = m.start(), m.end()
        id_str = orig_bytes[start:end].decode("ascii", errors="ignore")
        if id_str in mod_ids or id_str not in null_id_set: continue
        l_len = (end - start) + 5
        if start + l_len > len(orig_bytes): continue
        idx = bisect.bisect_left(swap_offsets, start)
        dist = 10**18
        if idx < len(swap_offsets): dist = min(dist, abs(swap_offsets[idx] - start))
        if idx > 0: dist = min(dist, abs(swap_offsets[idx - 1] - start))
        candidates.append((dist, start, l_len))
    for nid, h_str in id_to_hex.items():
        if nid in mod_ids: continue
        try:
            needle = bytes.fromhex(h_str)
            if len(needle) < 4: continue
            pos = start_search
            while True:
                pos = orig_bytes.find(needle, pos)
                if pos == -1: break
                l_len = len(needle) + 5
                if pos + l_len <= len(orig_bytes):
                    idx = bisect.bisect_left(swap_offsets, pos)
                    dist = 10**18
                    if idx < len(swap_offsets): dist = min(dist, abs(swap_offsets[idx] - pos))
                    if idx > 0: dist = min(dist, abs(swap_offsets[idx - 1] - pos))
                    candidates.append((dist, pos, l_len))
                pos += len(needle)
        except: pass
    candidates.sort(key=lambda x: x[0])
    applied = 0
    for dist, start, length in candidates:
        if applied >= max_nulls: break
        data[start : start + length] = b'\x00' * length
        applied += 1
    return data, applied

def zsdic_swap(data: bytearray, pair_ops: Dict, swap_offsets: Set[int] = None) -> List[Tuple[str,str,str,str]]:
    """Apply 2-way longhex (ID+5bytes) swap using ops built by zsdic_get_pair_ops."""
    modified = []
    temp_data = bytes(data)
    for (id1, id2), op_data in pair_ops.items():
        was_mod = False
        for op in op_data["ops"]:
            rx  = op["rx"]
            frm = op["from"]
            to  = op["to"]
            for m in rx.finditer(temp_data):
                pos = m.start()
                if pos + len(frm) > len(data): continue
                data[pos : pos + len(frm)] = to
                if swap_offsets is not None: swap_offsets.add(pos)
                was_mod = True
        if was_mod:
            modified.append((id1, id2, get_name(id1), get_name(id2)))
    return modified

def zsdic_dynamic_swap(data: bytearray, pairs: List[Tuple[str,str]], swap_offsets: Set[int] = None) -> List[Tuple[str,str,str,str]]:
    modified = []
    temp_data = bytes(data)  # original snapshot

    for have_id, want_id in pairs:
        have_bytes = have_id.encode('ascii')
        want_bytes = want_id.encode('ascii')
        have_len   = len(have_bytes)
        want_len   = len(want_bytes)

        pat_have = re.compile(rb"(?<![0-9])" + re.escape(have_bytes) + rb"(?![0-9])")
        pat_want = re.compile(rb"(?<![0-9])" + re.escape(want_bytes) + rb"(?![0-9])")

        # Collect all positions of each ID in original
        pos_have_list = [m.start() for m in pat_have.finditer(temp_data)
                         if m.start() + have_len + 5 <= len(data)]
        pos_want_list = [m.start() for m in pat_want.finditer(temp_data)
                         if m.start() + want_len + 5 <= len(data)]

        if not pos_have_list or not pos_want_list: continue

        # Extract full longhex blocks from original snapshot
        def get_lh(pos, id_len):
            return temp_data[pos : pos + id_len + 5]

        def adjust_lh(lh, target_len):
            """Adjust lh bytearray to exactly target_len bytes."""
            lh = bytearray(lh)
            diff = target_len - len(lh)
            if diff > 0:
                idx = lh.find(0x00)
                if idx < 0: lh.extend(b"\x00" * diff)
                else: [lh.insert(idx, 0x00) for _ in range(diff)]
            elif diff < 0:
                for _ in range(-diff):
                    idx = lh.find(0x00)
                    if idx >= 0: del lh[idx]
                    else: lh = lh[:target_len]
            return bytes(lh)

        was_mod = False

        # At each want position: write have's full longhex block
        for p in pos_want_list:
            lh_have = get_lh(pos_have_list[0], have_len)  # use first have occurrence
            replacement = adjust_lh(lh_have, want_len + 5)
            data[p : p + want_len + 5] = replacement
            if swap_offsets is not None: swap_offsets.add(p)
            was_mod = True

        # At each have position: write want's full longhex block
        for p in pos_have_list:
            lh_want = get_lh(pos_want_list[0], want_len)  # use first want occurrence
            replacement = adjust_lh(lh_want, have_len + 5)
            data[p : p + have_len + 5] = replacement
            if swap_offsets is not None: swap_offsets.add(p)
            was_mod = True

        if was_mod:
            modified.append((have_id, want_id, get_name(have_id), get_name(want_id)))

    return modified


def write_changelog(out_dir: Path, operation: str, txt_name: str, file_results: dict):
    lines = [
        f"{'='*60}",
        f"  SEMX TOOL - CHANGELOG",
        f"{'='*60}",
        f"  Date     : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"  Operation: {operation}",
        f"  Input TXT: {txt_name}",
        f"{'='*60}",
        ""
    ]
    total_modified = 0
    for fname, result in file_results.items():
        mods = result.get('modified', [])
        nulled = result.get('nulled', 0)
        total_modified += len(mods)
        lines.append(f"  File: {fname}")
        lines.append(f"  Pairs Modified: {len(mods)}")
        if mods:
            for h_id, w_id, h_name, w_name in mods:
                lines.append(f"    ✓ {h_id} ({h_name}) → {w_id} ({w_name})")
        else:
            lines.append(f"    (no pairs found in this file)")
        lines.append(f"  Hexes Nulled: {nulled}")
        lines.append("")

    lines.append(f"{'='*60}")
    lines.append(f"  TOTAL PAIRS MODIFIED: {total_modified}")
    lines.append(f"{'='*60}")

    (out_dir / "changelog.txt").write_text('\n'.join(lines), encoding='utf-8')

def process_files(src_dir: Path, out_dir: Path, rel_paths: List[str],
                  pairs: List[Tuple[str,str]], is_mini: bool,
                  null_count: int, auto_null: bool, operation: str, txt_name: str, null_txt: Path = None):
    orig_dir = out_dir / "original"
    mod_dir = out_dir / "modified"
    orig_dir.mkdir(parents=True, exist_ok=True)
    mod_dir.mkdir(parents=True, exist_ok=True)

    zsdic_ops = {}
    if not is_mini:
        # Build pattern ops using the first file in rel_paths as the source for longhex extraction
        item_data = []
        pattern_source = rel_paths[0]
        for p in src_dir.rglob(Path(pattern_source).name):
            try: item_data.append(p.read_bytes())
            except: pass
        if not item_data: # Fallback to Item.uasset if the target file isn't found in src_dir
            for p in src_dir.rglob("Item.uasset"):
                try: item_data.append(p.read_bytes())
                except: pass
        zsdic_ops = zsdic_get_pair_ops(pairs, item_data)

    protected_hex = build_protected_hex(pairs)
    protected_ids = build_protected_ids(pairs)
    null_ids_data = load_null_ids(null_txt)
    null_id_set = {nid for nid, h in null_ids_data}
    mod_ids = {p[0] for p in pairs} | {p[1] for p in pairs}
    
    file_results = {}
    grand_total = 0

    for rel in rel_paths:
        src_file = src_dir / rel
        if not src_file.exists():
            found = list(src_dir.rglob(Path(rel).name))
            if found:
                src_file = found[0]
                msg('!', f"Relocated {rel} -> {src_file.relative_to(src_dir)}")
            else:
                msg('x', f"Not found: {rel} — skipping")
                continue

        fname = src_file.name
        is_item = fname.lower() == "item.uexp"

        original_data = src_file.read_bytes()
        original_size = len(original_data)
        data = bytearray(original_data)
        swap_offsets = set()

        if is_mini:
            mods = mini_swap(data, pairs, is_item)
        else:
            mods = zsdic_dynamic_swap(data, pairs, swap_offsets)

        if mods:
            msg('+', f"{fname}: {len(mods)} pairs modified")
            for h_id, w_id, h_name, w_name in mods:
                print(f"      {CLR.G}✓{CLR.RST} {h_id} ({h_name}) → {w_id} ({w_name})")
        else:
            msg('!', f"{fname}: no matching pairs found")

        actual_null = 0
        limit = 0
        if auto_null and mods: limit = int(len(mods) * 1.5)
        elif null_count > 0: limit = null_count
        
        if limit > 0 and (not is_mini or not is_item_asset(fname)):
            if is_mini:
                actual_null = null_mini(data, limit, protected_hex, null_ids_data)
            else:
                if swap_offsets:
                    id_to_hex = {nid: h for nid, h in null_ids_data}
                    data, actual_null = null_zsdic_nearest(data, list(swap_offsets), null_id_set, id_to_hex, mod_ids, limit)
                else:
                    actual_null = null_zsdic(data, limit, protected_ids, null_ids_data)
            msg('*', f"{fname}: nulled {actual_null} (Limit: {limit})")

        if len(data) < original_size:
            data.extend(b'\x00' * (original_size - len(data)))
        elif len(data) > original_size:
            data = data[:original_size]

        m_out = mod_dir / rel
        m_out.parent.mkdir(parents=True, exist_ok=True)
        m_out.write_bytes(data)

        o_out = orig_dir / rel
        o_out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_file, o_out)

        file_results[rel] = {'modified': mods, 'nulled': actual_null}
        grand_total += len(mods)

    write_changelog(out_dir, operation, txt_name, file_results)

    print(f"\n  {CLR.T1}{'━'*42}{CLR.RST}")
    msg('+', f"TOTAL PAIRS MODIFIED: {grand_total}")
    msg('*', f"Output: {out_dir}")
    print(f"  {CLR.T1}{'━'*42}{CLR.RST}")

def ask_null_count(pair_count: int) -> int:
    msg('*', f"Loaded {pair_count} ID pairs from txt")
    null_ids = load_null_ids()
    msg('*', f"null.txt contains {len(null_ids)} null IDs")
    raw = input(f"  {CLR.N3}Enter null count [0 = skip]: {CLR.RST}").strip()
    if not raw: return 0
    try: return int(raw)
    except: return 0

def menu_mini():
    while True:
        header("MINI OBB PROCESSOR", "Hex-Based .uexp Modification")
        print(f"  {CLR.Y}1.{CLR.RST} HIT EFFECT")
        print(f"  {CLR.Y}2.{CLR.RST} LOOTCRATE")
        print(f"  {CLR.Y}3.{CLR.RST} SKINS")
        print(f"  {CLR.Y}4.{CLR.RST} LOBBY")
        print(f"  {CLR.R}0.{CLR.RST} BACK\n")
        ch = input(f"  {CLR.N2}❯ {CLR.RST}").strip()

        if ch == '1':
            header("MINI > HIT EFFECT", "Avatar Hit FX Data")
            pairs = load_pairs(Config.MODGUN)
            if not pairs: msg('x', "No pairs in modgun.txt"); input("\n  Press Enter..."); continue
            nc = ask_null_count(len(pairs))
            out = Config.MINI_OUT / "HIT_EFFECT"
            process_files(Config.MINI_SRC, out,
                         ['AvatarWeaponHitFXData.uexp'],
                         pairs, is_mini=True, null_count=nc, auto_null=False,
                         operation="HIT EFFECT", txt_name="modgun.txt")
            input("\n  Press Enter...")

        elif ch == '2':
            header("MINI > LOOTCRATE", "Weapon BP Attributes")
            pairs = load_pairs(Config.MODGUN)
            if not pairs: msg('x', "No pairs in modgun.txt"); input("\n  Press Enter..."); continue
            nc = ask_null_count(len(pairs))
            out = Config.MINI_OUT / "LOOTCRATE"
            process_files(Config.MINI_SRC, out,
                         ['WeaponAttrBPTable.uexp'],
                         pairs, is_mini=True, null_count=nc, auto_null=False,
                         operation="LOOTCRATE", txt_name="modgun.txt")
            input("\n  Press Enter...")

        elif ch == '3':
            run_mini_skins()

        elif ch == '4':
            run_mini_lobby()

        elif ch == '0': break


def menu_zsdic():
    while True:
        header("ZSDIC PROCESSOR", "LongHex-Based .uasset Modification")
        print(f"  {CLR.Y}1.{CLR.RST} FACE AND HAIRS")
        print(f"  {CLR.Y}2.{CLR.RST} KILL MESSAGE")
        print(f"  {CLR.Y}3.{CLR.RST} SKINS")
        print(f"  {CLR.R}0.{CLR.RST} BACK\n")
        ch = input(f"  {CLR.N2}❯ {CLR.RST}").strip()

        if ch == '1':
            header("ZSDIC > FACE AND HAIRS", "Character Customization")
            pairs = load_pairs(Config.MODCLOTH)
            if not pairs: msg('x', "No pairs in modcloth.txt"); input("\n  Press Enter..."); continue
            nc = ask_null_count(len(pairs))
            out = Config.ZSDIC_OUT / "FACE_AND_HAIRS"
            orig_dir = out / "original"; mod_dir = out / "modified"
            orig_dir.mkdir(parents=True, exist_ok=True); mod_dir.mkdir(parents=True, exist_ok=True)

            # Load reference data: AvatarSuitsTable (has id2) + Item.uasset (has id1)
            item_data = []
            for p in Config.ZSDIC_SRC.rglob("AvatarSuitsTable.uasset"):
                try: item_data.append(p.read_bytes())
                except: pass
            for p in Config.ZSDIC_SRC.rglob("Item.uasset"):
                try: item_data.append(p.read_bytes())
                except: pass
            if not item_data:
                msg('x', "No reference files found in ZSDIC_SRC"); input("\n  Press Enter..."); continue

            zsdic_ops = zsdic_get_pair_ops(pairs, item_data)
            protected_ids = build_protected_ids(pairs)
            null_ids_data = load_null_ids()

            target_file = None
            for p in Config.ZSDIC_SRC.rglob("AvatarSuitsTable.uasset"):
                target_file = p; break
            if not target_file:
                msg('x', "AvatarSuitsTable.uasset not found"); input("\n  Press Enter..."); continue

            import shutil as _sh_fh
            original_data = target_file.read_bytes()
            data = bytearray(original_data)
            swap_offsets = set()
            mods = zsdic_swap(data, zsdic_ops, swap_offsets)

            if mods:
                msg('+', f"AvatarSuitsTable.uasset: {len(mods)} pairs modified")
                for h_id, w_id, h_name, w_name in mods:
                    print(f"      {CLR.G}✓{CLR.RST} {h_id} ({h_name}) → {w_id} ({w_name})")
            else:
                msg('!', "AvatarSuitsTable.uasset: no matching pairs found")

            if len(data) < len(original_data): data.extend(b'\x00' * (len(original_data) - len(data)))
            elif len(data) > len(original_data): data = data[:len(original_data)]

            rel = "AvatarSuitsTable.uasset"
            (mod_dir / rel).write_bytes(data)
            _sh_fh.copy2(target_file, orig_dir / rel)

            if nc > 0 and mods and swap_offsets:
                id_to_hex = {nid: h for nid, h in null_ids_data}
                mod_ids = {p[0] for p in pairs} | {p[1] for p in pairs}
                null_id_set = {nid for nid, h in null_ids_data}
                data_ba = bytearray((mod_dir / rel).read_bytes())
                data_ba, nulled = null_zsdic_nearest(data_ba, list(swap_offsets), null_id_set, id_to_hex, mod_ids, nc)
                (mod_dir / rel).write_bytes(data_ba)
                msg('*', f"Nulled {nulled} entries")

            write_changelog(out, "FACE AND HAIRS", "modcloth.txt", {rel: {'modified': mods, 'nulled': nc}})
            print(f"\n  {CLR.T1}{'━'*42}{CLR.RST}")
            msg('+', f"Output: {out}")
            print(f"  {CLR.T1}{'━'*42}{CLR.RST}")
            input("\n  Press Enter...")


        elif ch == '2':
            header("ZSDIC > KILL MESSAGE", "Elite Battle Effects")
            out = Config.ZSDIC_OUT / "KILL_MESSAGE"
            orig_dir = out / "original"; mod_dir = out / "modified"
            orig_dir.mkdir(parents=True, exist_ok=True); mod_dir.mkdir(parents=True, exist_ok=True)

            pairs_cloth = load_pairs(Config.MODCLOTH)
            pairs_gun   = load_pairs(Config.MODGUN)

            if not pairs_cloth and not pairs_gun:
                msg('x', "No pairs in modcloth.txt or modgun.txt"); input("\n  Press Enter..."); continue

            nc = ask_null_count(max(len(pairs_cloth), len(pairs_gun)))
            null_ids_data = load_null_ids()
            null_id_set   = {nid for nid, h in null_ids_data}
            id_to_hex     = {nid: h for nid, h in null_ids_data}

            def _km_process(fname, pairs):
                target_file = None
                for p in Config.ZSDIC_SRC.rglob(fname):
                    target_file = p; break
                if not target_file:
                    msg('x', f"{fname} not found in ZSDIC_SRC"); return

                # Load target file + Item.uasset as reference (to get id1's suffix)
                item_data = []
                try: item_data.append(target_file.read_bytes())
                except: pass
                for p in Config.ZSDIC_SRC.rglob("Item.uasset"):
                    try: item_data.append(p.read_bytes())
                    except: pass

                zsdic_ops = zsdic_get_pair_ops(pairs, item_data)
                original  = target_file.read_bytes()
                data      = bytearray(original)
                swap_offsets = set()
                mods = zsdic_swap(data, zsdic_ops, swap_offsets)

                if mods:
                    msg('+', f"{fname}: {len(mods)} pairs modified")
                    for h_id, w_id, h_name, w_name in mods:
                        print(f"      {CLR.G}✓{CLR.RST} {h_id} ({h_name}) → {w_id} ({w_name})")
                else:
                    msg('!', f"{fname}: no matching pairs found")

                if len(data) < len(original): data.extend(b'\x00' * (len(original) - len(data)))
                elif len(data) > len(original): data = data[:len(original)]

                (mod_dir / fname).write_bytes(data)
                import shutil as _sh_km; _sh_km.copy2(target_file, orig_dir / fname)

                if nc > 0 and mods and swap_offsets:
                    mod_ids = {p[0] for p in pairs} | {p[1] for p in pairs}
                    data_ba = bytearray((mod_dir / fname).read_bytes())
                    data_ba, nulled = null_zsdic_nearest(data_ba, list(swap_offsets), null_id_set, id_to_hex, mod_ids, nc)
                    (mod_dir / fname).write_bytes(data_ba)
                    msg('*', f"Nulled {nulled} entries")

                write_changelog(out, f"KILL MESSAGE ({fname})", fname, {fname: {'modified': mods, 'nulled': nc}})

            if pairs_cloth:
                msg('*', "Processing GoldClothBattleEffect.uasset (modcloth.txt)...")
                _km_process("GoldClothBattleEffect.uasset", pairs_cloth)
            if pairs_gun:
                msg('*', "Processing WeaponAvatarBattleEffect.uasset (modgun.txt)...")
                _km_process("WeaponAvatarBattleEffect.uasset", pairs_gun)

            print(f"\n  {CLR.T1}{'━'*42}{CLR.RST}")
            msg('+', f"Output: {out}")
            print(f"  {CLR.T1}{'━'*42}{CLR.RST}")
            input("\n  Press Enter...")



        elif ch == '3':
            header("ZSDIC > SKINS", "Advanced Skin Mapping")
            pairs = load_pairs(Config.MODCLOTH)
            if not pairs: msg('x', "No pairs in modcloth.txt"); input("\n  Press Enter..."); continue
            nc = ask_null_count(len(pairs))
            out = Config.ZSDIC_OUT / "SKINS"
            process_files(Config.ZSDIC_SRC, out,
                         ['Item.uasset', 'InGame/EvoBase/CSV/Item.uasset'],
                         pairs, is_mini=False, null_count=nc, auto_null=False,
                         operation="SKINS", txt_name="modcloth.txt")
            input("\n  Press Enter...")

        elif ch == '0': break

def copy_data_to_repack():
    header("COPY DATA", "Mapping Modded Files to Repack Structure")
    base_dir = Path(__file__).parent
    repack_dir = base_dir / "REPACK"
    unpacked_root = repack_dir / "unpacked"
    
    if not unpacked_root.exists():
        msg('x', f"Folder not found: {unpacked_root}"); return

    mini_sources = [
        base_dir / "MINI" / "HIT_EFFECT" / "modified",
        base_dir / "MINI" / "LOOTCRATE" / "modified",
        base_dir / "MINI" / "SKINS" / "SIZE_FIXED",
        base_dir / "MINI" / "LOBBY" / "SIZE_FIXED"
    ]
    zsdic_sources = [
        base_dir / "ZSDIC" / "FACE_AND_HAIRS" / "modified",
        base_dir / "ZSDIC" / "KILL_MESSAGE" / "modified",
        base_dir / "ZSDIC" / "SKINS" / "modified",
        base_dir / "ZSDIC" / "LOBBY" / "modified"
    ]

    # Target folders inside unpacked/
    mini_target_root = unpacked_root / "mini_obb"
    zsdic_target_root = unpacked_root / "mini_obbzsdic_obb"

    def process_copy(label, search_dirs, target_root):
        if not target_root.exists():
            msg('!', f"Target folder {target_root.name} not found"); return 0
            
        edited_dir = target_root / "edited"
        edited_dir.mkdir(parents=True, exist_ok=True)
        
        # Build a map of all files in the unpacked folder for fast lookup
        # Key: filename.lower(), Value: list of relative paths from target_root
        unpacked_map = {}
        for orig_file in target_root.rglob("*"):
            if not orig_file.is_file(): continue
            if "edited" in orig_file.parts: continue
            
            name_lower = orig_file.name.lower()
            rel_path = orig_file.relative_to(target_root)
            if name_lower not in unpacked_map:
                unpacked_map[name_lower] = []
            unpacked_map[name_lower].append(rel_path)

        copied_count = 0
        for sdir in search_dirs:
            if not sdir.exists():
                # Don't spam if common folders are missing
                continue
            
            # Find all modded files in this search directory
            mod_files = [f for f in sdir.rglob("*") if f.is_file() and f.suffix.lower() in ['.uasset', '.uexp']]
            if not mod_files: continue
            
            msg('*', f"Scanning {label}: {sdir.relative_to(base_dir)} ({len(mod_files)} files)")
            
            for f in mod_files:
                name_lower = f.name.lower()
                if name_lower not in unpacked_map:
                    msg('!', f"Could not find {f.name} in unpacked PAK map. Skipping.")
                    continue
                
                # If there are multiple matches in the PAK, try to pick the best one
                # based on the relative path from the search directory (if any)
                best_rel = None
                possible_rels = unpacked_map[name_lower]
                
                if len(possible_rels) == 1:
                    best_rel = possible_rels[0]
                else:
                    # Try to match subfolders (e.g. InGame/EvoBase/CSV)
                    # We get the relative path of f from sdir
                    mod_rel = f.relative_to(sdir)
                    mod_parts = [p.lower() for p in mod_rel.parent.parts]
                    
                    max_matches = -1
                    for p_rel in possible_rels:
                        p_parts = [p.lower() for p in p_rel.parent.parts]
                        # Count how many common parts they have from the end
                        matches = 0
                        for m_p, p_p in zip(reversed(mod_parts), reversed(p_parts)):
                            if m_p == p_p: matches += 1
                            else: break
                        
                        if matches > max_matches:
                            max_matches = matches
                            best_rel = p_rel

                if best_rel:
                    dest = edited_dir / best_rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, dest)
                    msg('+', f"Mapped: {f.name} -> {best_rel.parent}")
                    copied_count += 1
                
        return copied_count

    total = process_copy("MINI", mini_sources, mini_target_root)
    total += process_copy("ZSDIC", zsdic_sources, zsdic_target_root)
    
    msg('+', f"Finished! Total files mapped to 'edited' folders: {total}")
    input("\n  Press Enter...")

def quick_repack():
    header("QUICK REPACK", "Automated PAK Rebuilder")
    
    repack_dir = Path(r"C:\Users\bhoit\Desktop\wasd\REPACK")
    if str(repack_dir) not in sys.path:
        sys.path.insert(0, str(repack_dir))
    
    # 1. Detect PAK
    pak_files = []
    for p in repack_dir.rglob("*.pak"):
        if "repacked_pak" in p.parts: continue
        pak_files.append(p)
        
    if not pak_files:
        msg('x', f"No .pak files found in {repack_dir}"); input("\n  Press Enter..."); return
    
    if len(pak_files) == 1:
        obb_path = pak_files[0]
    else:
        print(f"  {CLR.BOLD}{CLR.W}Select PAK to repack:{CLR.RST}")
        for i, p in enumerate(pak_files, 1):
            print(f"    {CLR.Y}{i}.{CLR.RST} {p.name}")
        try:
            p_idx = int(input(f"\n  {CLR.N2}Select [1-{len(pak_files)}]: {CLR.RST}")) - 1
            obb_path = pak_files[p_idx]
        except: return

    msg('*', f"Target PAK: {CLR.W}{obb_path.name}{CLR.RST}")

    # 2. Import Repacker
    try:
        from types import ModuleType
        if "termcolor" not in sys.modules:
            m = ModuleType("termcolor")
            m.colored = lambda text, color=None, on_color=None, attrs=None: text
            m.cprint = lambda text, color=None, on_color=None, attrs=None, **kwargs: print(text, **kwargs)
            sys.modules["termcolor"] = m

        import importlib.util
        main_path = repack_dir / "main.py"
        spec = importlib.util.spec_from_file_location("repacker_main", str(main_path))
        main_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(main_mod)
        TencentPakFile = main_mod.TencentPakFile
    except Exception as e:
        msg('x', f"Repacker error: {e}"); input("\n  Press Enter..."); return

    # 3. Trigger Repack immediately
    try:
        pak = TencentPakFile(obb_path)
        unpacked_root = repack_dir / "unpacked"
        
        # Decide which unpacked folder to use based on PAK name
        if "zsdic" in obb_path.name.lower():
            target_folder = unpacked_root / "mini_obbzsdic_obb"
        else:
            target_folder = unpacked_root / "mini_obb"
            
        if not target_folder.exists():
            # Fallback to name-based match
            target_folder = unpacked_root / obb_path.stem
            
        edited_dir = target_folder / "edited"
        if not edited_dir.exists():
            msg('x', f"Edited folder not found: {edited_dir}")
            msg('!', "Please run COPY DATA (Option 3) before repacking.")
            input("\n  Press Enter..."); return
            
        out_pak = repack_dir / "repacked_pak" / obb_path.name
        out_pak.parent.mkdir(parents=True, exist_ok=True)
        
        msg('*', "Repacking started...")
        pak.repack(edited_dir, out_pak)
        msg('+', f"DONE: {out_pak.name}")
    except Exception as e:
        msg('x', f"Repack failed: {e}")
        import traceback; traceback.print_exc()
        
    input("\n  Press Enter...")

def main():
    Config.MINI_OUT.mkdir(parents=True, exist_ok=True)
    Config.ZSDIC_OUT.mkdir(parents=True, exist_ok=True)
    while True:
        header("SEMX TOOL v5.0", "Next-Gen PUBG Modification Suite")
        print(f"  {CLR.Y}1.{CLR.RST} MINI OBB MODS")
        print(f"  {CLR.Y}2.{CLR.RST} ZSDIC MODS")
        print(f"  {CLR.Y}3.{CLR.RST} COPY DATA TO REPACK")
        print(f"  {CLR.Y}4.{CLR.RST} QUICK REPACK")
        print(f"  {CLR.R}0.{CLR.RST} EXIT\n")
        ch = input(f"  {CLR.N1}❯ {CLR.RST}").strip()

        if ch == '1': menu_mini()
        elif ch == '2': menu_zsdic()
        elif ch == '3': copy_data_to_repack()
        elif ch == '4': quick_repack()
        elif ch == '0':
            print(f"\n  {CLR.G}Goodbye!{CLR.RST}\n")
            break

if __name__ == "__main__":
    main()

